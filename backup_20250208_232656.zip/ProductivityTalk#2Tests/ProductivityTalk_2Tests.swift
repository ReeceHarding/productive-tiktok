//
//  ProductivityTalk_2Tests.swift
//  ProductivityTalk#2Tests
//
//  Created by Reece Harding on 2/7/25.
//

import Testing
@testable import ProductivityTalk_2

struct ProductivityTalk_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
